﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FileDecryptor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter infected path: ");
            var infectedPath = Console.ReadLine();
            var files = ScanFiles(infectedPath);

            Console.Write("Enter recovery path: ");
            var recoveryPath = Console.ReadLine();

            Console.Write("Enter encryption password: ");
            var password = Console.ReadLine();
            Console.WriteLine("\n");
            var fc = new FileCryptoService();
            foreach (var file in files)
            {
                var fileName = file.Split('\\').Last();
                Console.WriteLine($"Decrypting {file}");
                fc.FileDecrypt(file, $"{recoveryPath}\\{fileName}", password);
            }

            Console.WriteLine("\nDecryption completed.");
            Console.ReadKey();
        }

        private static List<string> ScanFiles(string path)
        {
            return new List<string>(Directory.EnumerateFiles(path));
        }
    }
}
